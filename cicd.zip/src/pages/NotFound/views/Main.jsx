import { Box } from '@chakra-ui/react';

const Main = () => (
  <Box data-test-id="3c6497a5">
    NotFound/Main
  </Box>
);

export default Main;
