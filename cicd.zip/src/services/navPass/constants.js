export const endpoints = {
  emailCode: '/codes/email',
  smsCode: '/codes/sms',
  users: '/users',
  orders: '/orders'
};
