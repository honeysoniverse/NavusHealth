const ASSETS = '/assets/';

export const images = {
  navusHealthBlueLogo: '../../public/navushealth-logo-blue.svg',
  navusLogoWhite: `${ASSETS}navus-logo-white.png`,
  testOrdered: `${ASSETS}test_ordered.png`,
  labProcessing: `${ASSETS}lab_processing.png`,
  reportReady: `${ASSETS}report_ready.png`,
  checkIcon: `${ASSETS}check.png`,
};
