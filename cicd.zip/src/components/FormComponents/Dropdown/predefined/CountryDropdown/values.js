export const countries = [
  {
    id: '0',
    label: 'United Kingdom',
    value: 'United Kingdom',
  },
  {
    id: '1',
    label: 'Italy',
    value: 'Italy',
  },
  {
    id: '2',
    label: 'Spain',
    value: 'Spain',
  },
  {
    id: '3',
    label: 'Malaysia',
    value: 'Malaysia',
  },
  {
    id: '4',
    label: 'Mexico',
    value: 'Mexico',
  },
  {
    id: '5',
    label: 'France',
    value: 'France',
  },
  {
    id: '6',
    label: 'Sweden',
    value: 'Sweden',
  },
  {
    id: '7',
    label: 'India',
    value: 'India',
  },
];
