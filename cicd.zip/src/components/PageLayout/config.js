import { pathNames } from '../../config/pathNames';

export const hiddenMenuRoutes = [
  pathNames.login,
];
