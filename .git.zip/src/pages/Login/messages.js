const messages = {
  errorLoginHeading: 'You were not able to log in.',
  errorLoginDescription: 'Authorization failed. Please try again.',
};

export default messages;
