export const race = [
  {
    id: '0',
    label: 'American Indian or Alaka Native',
    value: 'American Indian or Alaka Native',
  },
  {
    id: '1',
    label: 'Black or African American',
    value: 'Black or African American',
  },
  {
    id: '2',
    label: 'Native Hawaiian or Other Pacific Islander',
    value: 'Native Hawaiian or Other Pacific Islander',
  },
  {
    id: '3',
    label: 'Asian',
    value: 'Asian',
  },
  {
    id: '4',
    label: 'Hispanic or Latino',
    value: 'Hispanic or Latino',
  },
  {
    id: '5',
    label: 'White',
    value: 'White',
  },
  {
    id: '6',
    label: 'Unknown',
    value: 'Unknown',
  },
  {
    id: '7',
    label: 'Indian/Asian',
    value: 'Indian/Asian',
  },
];
