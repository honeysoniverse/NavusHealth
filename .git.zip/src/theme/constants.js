import { colors } from '../resources/colors';

export const INPUT_FIELD_HEIGHT = '50px';
export const INPUT_FIELD_BORDER_RADIUS = '12px';
export const INPUT_FIELD_BORDER_COLOR = colors.altoGray;
export const INPUT_LABEL_TEXT_SIZE = 14;
