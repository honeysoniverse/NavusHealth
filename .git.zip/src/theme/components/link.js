export const Link = {
  variants: {
    emailLink: {
      textAlign: 'center', // left, right
      fontSize: '16px', // font size
      lineHeight: '24px', // bold, italic
      textColor: '#313131', // which ever color
    },
  },
};
