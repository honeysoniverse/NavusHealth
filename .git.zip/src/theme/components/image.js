export const Image = {
  variants: {
    logo: {
      textAlign: 'center',
      marginBottom: '30px',
      marginTop: '30px',
      height: '124px',
    },
  },
};
