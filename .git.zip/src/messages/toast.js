const toast = {
  genericErrorHeading: 'Something went wrong',
  genericErrorDescription: 'Please try again later',
  requestTimeoutHeading: 'Slow network is detected',
  requestTimeoutDescription: 'Please try again later',
};

export default toast;
