const codes = {
  genericErrorHeading: 'Error on code verification',
  genericErrorDescription: 'Error description',
  genericSuccessHeading: 'Code sent on Phone Number',
  genericSuccessDescription: 'Please check you phone message',
};

export default codes;
