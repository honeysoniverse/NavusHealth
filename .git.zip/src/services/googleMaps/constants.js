export const endpoints = {
  placeDetails: '/place/details/json',
};
