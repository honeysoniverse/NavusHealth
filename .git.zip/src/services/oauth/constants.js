export const AUTH0_CODE_PARAM_NAME = 'code';
