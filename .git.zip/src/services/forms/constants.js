export const endpoints = {
  registrationMetadata: '/registrations/metadata',
  registrations: '/registrations',
};

export const resourceTimeout = 10000;
