export const AXIOS_CONNECTION_ABORTED_ERROR_CODE = 'ECONNABORTED';
export const AXIOS_TIMEOUT_ERROR_CODE = 'ETIMEDOUT';

export const resourceTimeout = 10000;
